import sys
import os
from PyQt5.QtWidgets import *
from menu2 import *
from MainApp import *
from Game import *
from theory import TheoryWindow
from achiev import Ui_Achievement
from PyQt5 import QtCore, QtGui, QtWidgets
from Cars import Form

class MainWindow2(Ui_MainWindow2, QMainWindow):

    def __init__(self, message="alnur",parent=None):
        QMainWindow.__init__(self)
        super(MainWindow2,self).__init__(parent)
        self.setupUi(self)
        self.UiComponentsForGames()
        self.message = message
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.Side_Menu_Num = 0
        self.toolButton.clicked.connect(lambda: self.Side_Menu_Def_0())
        self.show()

    def UiComponentsForGames(self):
        self.pushButton_Alien.clicked.connect(self.alienApp)
        self.pushButton_back.clicked.connect(self.previous_window)
        self.pushButton_Theory.clicked.connect(self.open_theory_window)
        self.your_achievements.clicked.connect(self.open_achieve_window)
        self.pushButton__car.clicked.connect(self.open_cars)

    def alienApp(self):
        self.close()
        stylesheet = """
            AlienWindow {
                background-image: url("bg.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """ 
        self.alien_window = AlienWindow(self.message)
        self.alien_window.setStyleSheet(stylesheet)
        self.alien_window.show()
        #self.close()
    
    def open_theory_window(self):
        self.close()
        self.theoryWindow = QtWidgets.QMainWindow()
        self.uiTheory = TheoryWindow()
        self.uiTheory.setupUi(self.theoryWindow)
        self.theoryWindow.show()

    def open_cars(self):
        self.close()
        self.carsWindow = Form(self.message)
        self.carsWindow.show()

    def open_achieve_window(self):
        self.close()
        self.achievemt_window = QtWidgets.QMainWindow()
        self.uiAchieve = Ui_Achievement(self.message)
        self.uiAchieve.setupUi(self.achievemt_window)
        self.achievemt_window.show()

    def previous_window(self):
        self.close()

    def Side_Menu_Def_0(self):
        if self.Side_Menu_Num ==0:
            self.animation1 = QtCore.QPropertyAnimation(self.frame_4, b"maximumWidth")
            self.animation1.setDuration(500)
            self.animation1.setStartValue(550)
            self.animation1.setEndValue(180)
            self.animation1.setEasingCurve(QtCore.QEasingCurve.InOutQuart)
            self.animation1.start()

            self.animation2 = QtCore.QPropertyAnimation(self.frame_4, b"minimumWidth")
            self.animation2.setDuration(500)
            self.animation2.setStartValue(50)
            self.animation2.setEndValue(180)
            self.animation2.setEasingCurve(QtCore.QEasingCurve.InOutQuart)
            self.animation2.start()

            self.Side_Menu_Num = 1
        else:
            self.animation1 = QtCore.QPropertyAnimation(self.frame_4, b"maximumWidth")
            self.animation1.setDuration(500)
            self.animation1.setStartValue(155)
            self.animation1.setEndValue(50)
            self.animation1.setEasingCurve(QtCore.QEasingCurve.InOutQuart)
            self.animation1.start()

            self.animation2 = QtCore.QPropertyAnimation(self.frame_4, b"minimumWidth")
            self.animation2.setDuration(500)
            self.animation2.setStartValue(155)
            self.animation2.setEndValue(50)
            self.animation2.setEasingCurve(QtCore.QEasingCurve.InOutQuart)
            self.animation2.start()

            self.Side_Menu_Num = 0

if __name__ == '__main__':
    app = QApplication(sys.argv)

    window = MainWindow2()
    window.show()
    sys.exit(app.exec())

    