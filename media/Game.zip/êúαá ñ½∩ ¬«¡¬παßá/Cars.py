import sys
import time, random
import regex as re
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon, QMovie, QFont
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import QRect, QPropertyAnimation, QSize, QPoint, QTimer, QParallelAnimationGroup
from threading import Thread
from database import *


class Form(QDialog):
    def __init__(self, message="alnur"):
        super().__init__()
        self.message = message
        self.setWindowTitle('Car racing') # add widgets, set property
        self.resize(670, 550)
        #Машинки
        #self.car_1 = QLabel(self)
        #self.car_2 = QLabel(self)
        #self.car_1.setPixmap(QtGui.QPixmap(r"CarGifs\0_0_photo-resizer.ru.png"))
       # self.car_2.setPixmap(QtGui.QPixmap(r"CarGifs\9_1_photo-resizer.ru.png"))
       # self.car_1.move(0, 100)

        self.background = QLabel(self)
        self.movie = QMovie("CarGifs/backgroundRoad")
        self.background.setMovie(self.movie)
        self.movie.start()

        self.score = QLabel(self)
        self.score.setText("Score: ")
        self.score.move(350, 403)
        self.score.resize(150,30)

        self.animationGroup = QParallelAnimationGroup(self)

        font = QtGui.QFont()
        font.setPointSize(11)
        font.setFamily("Cascadia Mono")
        font.setWeight(12)
        self.score.setFont(font)

        self.car = QLabel(self)
        self.carMovie = QMovie("CarGifs/car2")
        self.car.move(0,310)
        self.car.setMovie(self.carMovie)
        self.carMovie.start()

        self.enemy_car = QLabel(self)
        self.enemy_carMovie = QMovie("CarGifs/enemy_car (1)")
        self.enemy_car.move(100,260)
        self.enemy_car.setMovie(self.enemy_carMovie)
        self.enemy_carMovie.start()
        font = QtGui.QFont()
        font.setFamily("Cascadia Mono")
        font.setPointSize(14)

        self.equation = QLabel("Solve these problems!", self)
        self.equation.setFont(font)
        self.equation.move(10,453)
        self.equation.resize(700,50)
        #Поле ввода
        self.input_text = QLineEdit(self)
        self.input_text.resize(150,30)
        self.input_text.move(150, 405)
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setFamily("Cascadia Mono")
        font.setWeight(75)
        self.input_text.setFont(font)
        self.input_text.setEnabled(False)
        self.input_text.setStyleSheet("QLineEdit{\n"
"    border: 2px solid rgb(59, 59, 59);\n"
"    border-radius: 10px;\n"
"}\n"
"QPushButton:pressed{\n"
"    background-color:rgb(255, 241, 234)\n"
"\n"
"}")    

        font = QtGui.QFont()
        font.setPointSize(11)
        font.setFamily("Times")
        font.setWeight(75)
        self.result = QLabel("", self)
        self.result.setFont(font)
        self.result.move(10,500)
        self.result.resize(550,50)

        #Кнопка старт
        self.start = QPushButton(self)
        self.start.setText("Start")
        self.start.resize(100, 30)
        self.start.move(10, 403)
        font = QtGui.QFont()
        font.setFamily("Cascadia Mono")
        font.setPointSize(12)
        self.bot_flag = True
        self.start.setFont(font)
        self.start.clicked.connect(self.start_action)
        self.start.setStyleSheet("QPushButton{\n"
"    border: 2px solid rgb(59, 59, 59);\n"
"    border-radius: 10px;\n"
"}\n"
"QPushButton:pressed{\n"
"    background-color:rgb(255, 241, 234)\n"
"\n"
"}")    
        #Данные
        self.input_text.returnPressed.connect(self.user_action)
        font = QFont('Times', 23)
        self.score_value = 0
        self.count = QLabel("0", self)
        self.count.setFont(font)
        self.count.move(580,400)
        self.count.resize(50, 35)
        self.count_value = 0
        name_temp = sheet.find(self.message, in_column=2)
        self.USE_THIS = sheet.cell(name_temp.row+0, name_temp.col+6)
        achievements_temp = str(self.USE_THIS)
        ach = achievements_temp.split(', ')
        ach[0] = ach[0][12:]
        ach[-1] = ach[-1][:ach[-1].index("'>")]
        temp_ach = [v.split(' ') for v in ach]
        self.ACHIEVEMENTS_DICT = {"".join(k)[:"".join(k).index(":")]:v for k in temp_ach for v in k}
        print(self.ACHIEVEMENTS_DICT)
        self.equations_dict = {"1": '2x^2-4x+2=0', "0": '5x^2=0', "56": '7 * 8 =', "63": '7 * 9 =', "11": '6 + 5 =',
            "13": '7 + 6 =', "9": '4 + 5 =', "16": '8 + 8 =', "2": '1 + 1 =', "4": '2 * 2 =', "12": '4 * 3 =', "15": '5 * 3 =', 
            "32": '8 * 4 ='}
        self.coolBoy()
        self.equations_list = list(self.equations_dict.values())
        self.answer_list = list(self.equations_dict.keys())
        

    def show_time(self):
        self.count.setText(str(self.count_value))
        self.count_value += 1

    def check_true_or_false(self, ach_num):
        for v, k in self.ACHIEVEMENTS_DICT.items():
            if v == ach_num:
                return k == "False"

    def convert_dict_to_str(self, dct):
        TEMP = ""
        for k, v in dct.items():
            TEMP += k+": " +v+", "
        return TEMP[:-2]

    def make_true(self, dct, ach):
        for k, _ in dct.items():
            if k == ach:
                dct[k] = "True"
        return dct

    def helpTheDriver(self):
        if self.check_true_or_false("Ach1"):
            temp_dict = self.ACHIEVEMENTS_DICT
            dct = self.make_true(temp_dict, "Ach1")
            res = self.convert_dict_to_str(dct)
            sheet.update_cell(self.USE_THIS.row+0,self.USE_THIS.col+0,res)
            return True
        return False
    def coolBoy(self):
        if self.check_true_or_false("Ach2"):
            temp_dict = self.ACHIEVEMENTS_DICT
            dct = self.make_true(temp_dict, "Ach2")
            res = self.convert_dict_to_str(dct)
            sheet.update_cell(self.USE_THIS.row+0,self.USE_THIS.col+0,res)
            return True
        return False
    def winIn120sec(self):
        if self.check_true_or_false("Ach3"):
            temp_dict = self.ACHIEVEMENTS_DICT
            dct = self.make_true(temp_dict, "Ach3")
            res = self.convert_dict_to_str(dct)
            sheet.update_cell(self.USE_THIS.row+0,self.USE_THIS.col+0,res)
            return True
        return False
    def winIn60sec(self):
        if self.check_true_or_false("Ach4"):
            temp_dict = self.ACHIEVEMENTS_DICT
            dct = self.make_true(temp_dict, "Ach4")
            res = self.convert_dict_to_str(dct)
            sheet.update_cell(self.USE_THIS.row+0,self.USE_THIS.col+0,res)
            return True
        return False
    def winIn30sec(self):
        if self.check_true_or_false("Ach5"):
            temp_dict = self.ACHIEVEMENTS_DICT
            dct = self.make_true(temp_dict, "Ach5")
            res = self.convert_dict_to_str(dct)
            sheet.update_cell(self.USE_THIS.row+0,self.USE_THIS.col+0,res)
            return True
        return False
    def achieveScore30(self):
        if self.check_true_or_false("Ach6"):
            temp_dict = self.ACHIEVEMENTS_DICT
            dct = self.make_true(temp_dict, "Ach6")
            res = self.convert_dict_to_str(dct)
            sheet.update_cell(self.USE_THIS.row+0,self.USE_THIS.col+0,res)
            return True
        return False
    def achieveScore50(self):
        if self.check_true_or_false("Ach7"):
            temp_dict = self.ACHIEVEMENTS_DICT
            dct = self.make_true(temp_dict, "Ach7")
            res = self.convert_dict_to_str(dct)
            sheet.update_cell(self.USE_THIS.row+0,self.USE_THIS.col+0,res)
            return True
        return False

    def start_action(self):
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.show_time)
        self.timer.start(1000)
        self.start.setEnabled(False)
        self.score.setText("Your Score: 0")
        self.score_value = 0
        self.input_text.clear()
        self.input_text.setEnabled(True)
        self.random_equation = random.choice(self.equations_list)
        self.equation.setText(self.random_equation)


    def user_action(self):
        if self.car.x() < 500:
            text = self.input_text.text()
            if text in self.answer_list:
                if self.answer_list.index(text) == self.equations_list.index(self.random_equation):
                    self.input_text.clear()
                    self.score_value += 1
                    #self.score_animation(self.sc_user, self.sc_anim_user)
                    self.score.setText("Score: " + str(self.score_value))
                    self.random_equation = random.choice(self.equations_list)
                    self.equation.setText(self.random_equation)
                    self.anim_user = QPropertyAnimation(self.car, b'pos')
                    self.anim_user.setStartValue(self.car.pos())
                    r = self.car.x() + random.randint(25,50)
                    self.anim_user.setEndValue(QPoint(r, 310))
                    self.anim_user.setDuration(1000)
                    
                    self.anim_bot = QPropertyAnimation(self.enemy_car, b'pos')
                    self.anim_bot.setStartValue(self.enemy_car.pos())
                    r = self.enemy_car.x() + random.randint(25,50)
                    self.anim_bot.setEndValue(QPoint(r, 260))
                    self.anim_bot.setDuration(1000)

                    self.animationGroup.addAnimation(self.anim_user)
                    self.animationGroup.addAnimation(self.anim_bot)
                    n = random.randint(1,3)
                    if n == 1:
                        self.animationGroup.start()
                    else:
                        self.anim_user.start()
        else:
            self.helpTheDriver()
            self.equation.setText("Thanks you for helping surpassing this man!")
            self.timer.stop()
            name = sheet.find(self.message, in_column=2)
            existed_score = sheet.cell(name.row+0, name.col+5)
            if not "None" in str(existed_score):
                temp = re.compile(r"('\w+')")
                temp2 = temp.search(str(existed_score)).group()
                MAIN_EXISTED_SCORE = str(int(temp2[1:len(temp2)-1])+1)
            self.start.setEnabled(False)
            self.input_text.setEnabled(False)
            res = 0
            if int(self.count.text()) >= 60 and int(self.count.text()) <= 120:
                self.winIn60sec()
            if int(self.count.text()) <= 30:
                self.winIn30sec()
                res += int(1.5*self.score_value)
            elif int(self.count.text()) <= 60:
                self.winIn60sec()
                res += int(1.2*self.score_value)
            name = sheet.find(self.message, in_column=2)
            if res > 30 and res < 50:
                self.achieveScore30()
            if res >= 50:
                self.achieveScore50
            if "None" in str(existed_score):
                sheet.update_cell(name.row+0, name.col+5, str(res))
                self.result.setText("Yeah! Your first win")
            elif not "None" in str(existed_score) or int(MAIN_EXISTED_SCORE) < res:
                sheet.update_cell(name.row+0, name.col+5, str(res))
                self.result.setText("Yeah! New Score")
            elif not "None" in str(existed_score) and int(MAIN_EXISTED_SCORE) >= res:
                self.result.setText("Sadly, it's not your best result")

if __name__== '__main__':
    app = QApplication(sys.argv) ## create application
    dlgMain = Form() # create main GUI window
    dlgMain.show() #show GUI
    sys.exit(app.exec_()) ## execute application