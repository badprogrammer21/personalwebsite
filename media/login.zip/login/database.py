import gspread
from oauth2client.service_account import ServiceAccountCredentials

scope = ["https://www.googleapis.com/auth/spreadsheets",
		"https://www.googleapis.com/auth/drive.file",
		"https://www.googleapis.com/auth/drive"]

credentials = ServiceAccountCredentials.from_json_keyfile_name("databaseformath-45cc085a982d.json", scope)
client = gspread.authorize(credentials)
sheet = client.open("FirstSheet").sheet1